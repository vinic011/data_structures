#ifndef LAB1_HASH_FUNCS_H
#define LAB1_HASH_FUNCS_H

#include <string>
#include <iostream>

int hashdiv(std::string str, int m ) ;
int hashdiv29(std::string str) ;



#endif
