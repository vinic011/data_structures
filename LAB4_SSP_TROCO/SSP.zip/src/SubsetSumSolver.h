#ifndef SSP_SOLVER
#define SSP_SOLVER


#include <vector>
#include <string>
#include <SubsetSumSolverAbstract.h>


class SSPSolverAluno2 : public SubsetSumSolverAbstract {

    
public:
    
    virtual bool solve(const std::vector< long> &input,
                        long value, std::vector< char> &output);
        
    virtual std::string getName() { return "A2"; }
    
}; 

class SSPSolverExtra : public SubsetSumSolverAbstract {

    
public:
    
    virtual bool solve(const std::vector< long> &input,
                        long value, std::vector< char> &output);
        
    virtual std::string getName() { return "EX"; }
    
}; 

class SSPSolverPD : public SubsetSumSolverAbstract {

public:
    
    virtual bool solve(const std::vector< long> &input,
                        long value, std::vector< char> &output);
    
    virtual std::string getName() { return "PD"; }
    
}; 

#endif
