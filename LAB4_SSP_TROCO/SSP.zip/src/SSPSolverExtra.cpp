#include <SubsetSumSolver.h>



 bool SSPSolverExtra::solve(const std::vector< long> &input,
                            long value, std::vector< char> &output) {
    
    
    return false;
    
}
