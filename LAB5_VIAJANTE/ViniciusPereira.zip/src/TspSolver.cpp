#include <heap.h>
#include <algorithm>

void pre_order(int id, std::vector<int>& percourse, std::vector<std::vector<std::pair<int,int>>> min_tree) {
    percourse.push_back(id);
    //std::cout << "ID: " << id << "\n";
    for (int j = 0; j < min_tree[id - 1].size(); j++) {
        pre_order(min_tree[id-1][j].first, percourse, min_tree);
    }
}


void TspSolver::solve(TspReader &tr,std::vector<int> &percourse) {
        // here it is filling the vector with  1,2,3,...n
        // you should fill it with a permutation that represents the TSP solution

        graph g(tr);
        heap h(g);
        std::vector<bool> visited(g.num_cities, false);
        std::vector<std::vector<std::pair<int,int>>> min_tree(g.num_cities);

        while (!h.pq.empty()) {
            int w = -h.pq.top().first;
            int from = -h.pq.top().second.first;
            int to = -h.pq.top().second.second;
            h.pq.pop();
            if (!visited[to - 1]) {
                visited[to - 1] = true;
                if (from > 0) {
                    min_tree[from-1].push_back(std::make_pair(to,w));
                }
                //std::cout << "from: " << from << " to: " << to << " index: " <<++i<< " num cities: "<< visited[visited.size() - 1]<<"\n" ;
                for (int nbr = 0; nbr < g.num_cities; nbr++) {
                    if (!visited[nbr]) {
                        h.add_edge(to, nbr + 1, g);
                    }
                }
            }
        }

        // for (int i = 0; i < min_tree.size(); i++) {
        //     std::cout << "column : " << i+1 << " |";
        //     for (auto x: min_tree[i]) {
        //         std::cout << "("<< x.first << "," << x.second << ") ";
        //     }
        //     std::cout << "\n";
        // }
        pre_order(1, percourse, min_tree);
        //std::sort(percourse.begin(),percourse.end());
        // for (int j = 0; j < g.num_cities; j++) {
        //     std::cout << percourse[j] << " ";
        // }
    
}//solve

